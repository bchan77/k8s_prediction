#!/bin/bash

MODEL_ID=$1

sed "s/mlops-pps/mlops-pps-$MODEL_ID/g" pps-deployment.yaml > pps-deployment-$MODEL_ID.yaml
kubectl apply -f pps-deployment-$MODEL_ID.yaml




