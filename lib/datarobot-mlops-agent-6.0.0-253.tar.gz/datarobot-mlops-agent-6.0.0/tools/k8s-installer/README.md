This code will deploy a prediction environment in an already existing kubernetes platform.
At this point this code is cloud-agnostic and can be deployed into any flavor of cloud/kubernetes.

Assumptions:
- We will be using Portable Prediction Server (PPS)
- We will be using mlops-agents
- RabbitMQ deployment will be added as soon as it's ready
- Current state of PPS is to serve one single model at the time. If this fact changes, deployment will be changed too


Plan:
- We will deploy a group of Agent pods (pre-defined number of them) as a k8s deployment
- Agent will deploy PPS deployments for each model by running ‘run-pps.sh model_id’
- We will deploy a PPS service for each model deployment



