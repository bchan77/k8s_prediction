# This script takes an input file and generates and output file of the specified length.
# If the input file is 10K and 25K is desired, it will copy the input file 2.5 times
# to generate the output file.
# Note: the header line is not included in the file length count and will be included in
# the output file exactly once no matter the length of the file.

if [ $# -lt 3 ]
then
  echo usage: $0 input_file desired_lines output_file
  exit 1
fi

file=$1
lines=$2
outfile=$3

headers=`head -n 1 $file`
all_file_lines=`wc -l $file | sed 's/^[\ \t][\ \t]*//' | sed 's/[\ \t].*$//'`
echo All file lines: $all_file_lines
file_lines=`expr $all_file_lines - 1`
echo Non-header lines: $file_lines
needed_lines=$lines

# output header
echo $headers > outfile

# output copies of body lines
while [ $needed_lines -gt $file_lines ]
do
  `cat $file | tail -n $all_file_lines >> $outfile`
  needed_lines=`expr $needed_lines - $file_lines`
  echo Copied file. Remaining lines: $needed_lines
done

# output remainder body lines
if [ $needed_lines > 0 ]
then
  tail_lines=`expr $needed_lines + 1`
  `cat $file | tail -n $tail_lines >> $outfile`
  echo Added remainder: $needed_lines
fi
