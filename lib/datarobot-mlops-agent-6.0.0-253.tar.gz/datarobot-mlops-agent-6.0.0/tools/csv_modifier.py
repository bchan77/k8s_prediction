import argparse
import pandas as pd


class CSVModifier(object):

    def __init__(self, df, column_name):
        if column_name not in df.columns:
            raise Exception(
                "Column '{}' is not present in CSV. Allowed columns: {}".format(
                    column_name, df.columns
                )
            )

        self.df = df
        self.column_name = column_name

    def change(self):
        raise NotImplementedError("Please implement the change in modifier")

    def save(self, filename):
        self.df.to_csv(filename, encoding="utf-8", index=False)


class CSVModifierAddSubtractValue(CSVModifier):

    def __init__(self, df, column_name, change_value):
        super(CSVModifierAddSubtractValue, self).__init__(df, column_name)

        # Only float / int columns allowed to be changed here
        data_type = self.df[column_name].dtype
        if data_type not in [float, int]:
            raise Exception("Invalid column for change by value")
        self.change_value = change_value

    def change(self):
        self.df[self.column_name] += change_value


class CSVModifierAddSubtractPercentValue(CSVModifier):

    def __init__(self, df, column_name, percent_change_value):
        super(CSVModifierAddSubtractPercentValue, self).__init__(df, column_name)

        # Only float / int columns allowed to be changed here
        data_type = self.df[column_name].dtype
        if data_type not in [float, int]:
            raise Exception("Invalid column for change by value")
        self.percent_change_value = percent_change_value

    def change(self):
        self.df[self.column_name] += ((self.df[self.column_name] * self.percent_change_value) / 100)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv-filename", dest="csv_filename", required=True,
                        help="Name of CSV file to modify")
    parser.add_argument("--column-name", dest="column_name", required=True,
                        help="Name of the column in CSV to modify")
    parser.add_argument("--change-column-value", dest="change_value", required=False,
                        help="Each value in the column is changed by this amount.  For decrementing"
                             "the value, use negative number.  This will have effect of existing"
                             "distribution of values to shift to left or right")
    parser.add_argument("--change-column-value-by-percent", dest="change_value_percent",
                        required=False, help="Each value in the column is changed by this "
                                             "percentageamount.  For decrementing the "
                                             "value, use negative number.")
    parser.add_argument("--output-csv-filename", dest="output_csv_filename", required=True,
                        help="Target CSV File to store after modification")

    args = parser.parse_args()

    df = pd.read_csv(args.csv_filename)

    if args.change_value:
        change_value = int(args.change_value)
        modifier = CSVModifierAddSubtractValue(df, args.column_name, change_value)
    elif args.change_value_percent:
        percent_change_value = int(args.change_value_percent)
        modifier = CSVModifierAddSubtractPercentValue(df, args.column_name, percent_change_value)
    else:
        raise Exception("Invalid modifier specified")

    modifier.change()
    modifier.save(args.output_csv_filename)
