# This example code shows how to use the MLOps library to report metrics from external models into
# DataRobot's model management service.

# First set your deployment ID and model ID. These can be obtained by running the script to
# create_new_deployment.py
# However, when using CodeGen models, you should get the model ID by querying the CodeGen model itself.
# If you are running with the agent, make sure you get a valid deployment ID before running the examples.
#export MLOPS_DEPLOYMENT_ID=5
#export MLOPS_MODEL_ID=7

# Set your output type. To begin, you may wish the output to go to stdout.
# This will display the metrics to stdout instead of reporting them to DataRobot's
# service. This is useful during development.
#export MLOPS_OUTPUT_TYPE=STDOUT

# When you are ready to publish your metrics to the DataRobot service,
# uncomment the lines below.
# You need to configure the output to be stored in a directory and ensure that directory exists.
export MLOPS_OUTPUT_TYPE=OUTPUT_DIR
export MLOPS_SPOOLER_DIR_PATH=/tmp/ta

# Configure the maximum number of files and the maximum file size for output files recording the statistics.
# If your prediction traffic is bursty, consider having more, larger files.
# If your environment is space-constrained, you may require a smaller file size.
export MLOPS_SPOOLER_MAX_FILES=5
export MLOPS_SPOOLER_FILE_MAX_SIZE=1045876000

# To run, first set your java home. For example:
if [[ -z ${JAVA_HOME} ]]; then
    if command -v /usr/libexec/java_home >/dev/null 2>&1 ; then
        export JAVA_HOME=$(/usr/libexec/java_home -v 1.8)
    else
        echo "JAVA_HOME needs to be set to run example."
        exit 1
    fi
fi


# Make sure Spark is configured
if [[ -z ${SPARK_BIN} ]]; then
    echo "SPARK_BIN needs to be set to the directory containing spark-submit."
    echo "For example, /opt/spark-2.4.5-bin-hadoop2.7/bin"
    exit 1
fi

# If using CodeGen model, uncomment these.
CODEGEN_JAR="--jars ../../models/CodeGenLendingClubRegressor.jar"
MODEL_ID="5d4872f6962d7473b5a4d96b"

# Then execute the JAR file.
MODEL_FILE="../../models/CodeGenLendingClubRegressor.jar"
DATA_FILE="../../data/lending-club-regression.csv"
SPARK_OPTS="--num-executors 1 --driver-memory 512m --executor-memory 512m --executor-cores 1"
PROGRAM_CLASS="--class com.datarobot.dr_mloa_spark.Main"
PROGRAM_JAR="./target/dr-mloa-spark-1.0-SNAPSHOT-uber.jar"
SPARK_CMD="${SPARK_BIN}/spark-submit ${CODEGEN_JAR} ${PROGRAM_CLASS} ${SPARK_OPTS} ${PROGRAM_JAR}"

CMD="${SPARK_CMD} ${DATA_FILE} ${MODEL_ID}"
echo ${CMD}
${CMD}

# If the agent is running (and you have set the deployment ID as indicated above), you will see the statistics
# in the DataRobot UI under the Deployments tab.
