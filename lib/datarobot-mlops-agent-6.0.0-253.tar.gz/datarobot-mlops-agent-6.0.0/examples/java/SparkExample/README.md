# Spark Example
This example demonstrates using MLOps library integration into a scoring Spark DataFrame.

## Basic steps to set up Spark locally
- Download Spark 2.4.5 built for Hadoop 2.7 onto your local machine: http://spark.apache.org/downloads.html
- Unarchive the tarball: `tar xvf ~/Downloads/spark-2.4.5-bin-hadoop2.7.tgz`
- In the created `spark-2.4.5` directory, start you spark cluster:
  - `sbin/start-master.sh -i localhost`
  - `sbin/start-slave.sh -i localhost -c 8 -m 2G spark://localhost:7077`
- Ensure your installation is successful: `bin/spark-submit --class org.apache.spark.examples.SparkPi --master spark://localhost:7077 --num-executors 1 --driver-memory 512m --executor-memory 512m --executor-cores 1 examples/jars/spark-examples_2.11-2.4.5.jar 10`

## Build this project
- `mvn package` or `make`

## Make sure the agent is configured
- edit conf/mlops.agent.conf.yaml

## Create the deployment
./create_deployment.sh

## Run the example
./run_example.sh
