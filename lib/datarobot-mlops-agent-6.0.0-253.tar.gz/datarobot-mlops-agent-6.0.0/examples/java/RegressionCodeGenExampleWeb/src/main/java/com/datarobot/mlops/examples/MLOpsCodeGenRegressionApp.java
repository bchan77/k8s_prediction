package com.datarobot.mlops.examples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MLOpsCodeGenRegressionApp {

	public static void main(String[] args) {
		SpringApplication.run(MLOpsCodeGenRegressionApp.class, args);
	}

}
