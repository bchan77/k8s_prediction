package com.datarobot.mlops.examples.controller;

import com.datarobot.mlops.MLOps;
import com.datarobot.mlops.common.exceptions.DRCommonException;
import com.datarobot.prediction.IRegressionPredictor;
import com.datarobot.prediction.Predictors;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.stream.Collectors;

@RestController
public class PredictController {

	private static final Logger logger = LoggerFactory.getLogger(PredictController.class);

	private IRegressionPredictor predictor;
	private MLOps mlops = null;
	private JsonElement podInfo;

	private JsonElement loadPodInfo() throws IOException {
		Map<String, String> infoMap = new HashMap<>();
		String hostname = new BufferedReader(
				new InputStreamReader(Runtime.getRuntime().exec("hostname").getInputStream()))
				.readLine();

		infoMap.put("pod_name", System.getenv("MY_POD_NAME"));
		infoMap.put("pod_namespace", System.getenv("MY_POD_NAMESPACE"));
		infoMap.put("pod_ip", System.getenv("MY_POD_IP"));
		infoMap.put("hostname", hostname);

		logger.info(String.format("Pod info: %s", infoMap.toString()));
		return new Gson().toJsonTree(infoMap);
	}
	@PostConstruct
	public void init() {
		try {
			String modelFilePath = System.getenv("MLOPS_MODEL_PATH");
			if (modelFilePath == null || modelFilePath.isEmpty()) {
				throw new IllegalArgumentException("please provide MLOPS_MODEL_PATH");
			}

			File filePath = new File(modelFilePath);
			URL[] urls = new URL[]{new URL("file://" + filePath.getCanonicalPath())};
			URLClassLoader urlClassLoader = new URLClassLoader(urls);

			this.predictor = Predictors.getPredictor(urlClassLoader);
			this.mlops = MLOps.getInstance().init();
			this.podInfo = loadPodInfo();
		} catch (Exception e) {
			System.out.println("Failed to load model. " + e.getMessage());
			System.exit(1);
		}
	}

	@RequestMapping(value = "/info", method = RequestMethod.GET, produces={"application/json"})
	public String info() {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("time", new Date().toString());
		jsonObject.add("info", this.podInfo);

		logger.info("/info : " + jsonObject.toString());
		return jsonObject.toString();
	}

	@RequestMapping(value = "/predict", method = RequestMethod.POST, produces={"application/json"})
	public String predict(@RequestBody Map<String, Object> sample) {
		try {
			long startTime = System.currentTimeMillis();
			Double score = predictor.score(sample);
			long predictionTimeMs = System.currentTimeMillis() - startTime;

			Map<String, List<Object>> slicedfeatureData = sample.keySet().stream()
					.collect(Collectors.toMap(
							key -> key,
							key -> Collections.singletonList(sample.get(key))
					));

			mlops.reportPredictionsData(slicedfeatureData,
					Collections.singletonList(score),
					null,
					null);
			mlops.reportDeploymentStats(1, predictionTimeMs);

			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("prediction", score);
			jsonObject.addProperty("prediction_time_ms", predictionTimeMs);
			jsonObject.addProperty("time", new Date().toString());
			jsonObject.add("pod_info", this.podInfo);

			logger.info("prediction: " + score);
			return  jsonObject.toString();
		} catch (Exception e) {
			logger.error("Exception while doing prediction: ", e);
			return e.getMessage();
		}
	}

}
