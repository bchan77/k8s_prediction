# This example code shows how to use the MLOps library to report metrics from external models into
# DataRobot's model management service.

# First set your deployment ID and model ID. These can be obtained by running the script to
# create_new_deployment.py
# However, when using CodeGen models, you should get the model ID by querying the CodeGen model itself.
# If you are running with the agent, make sure you get a valid deployment ID before running the examples.
#export MLOPS_DEPLOYMENT_ID=5
#export MLOPS_MODEL_ID=7

# Set your output type. To begin, you may wish the output to go to stdout.
# This will display the metrics to stdout instead of reporting them to DataRobot's
# service. This is useful during development.
#export MLOPS_OUTPUT_TYPE=STDOUT

# When you are ready to publish your metrics to the DataRobot service,
# uncomment the lines below.
# You need to configure the output to be stored in a directory and ensure that directory exists.
export MLOPS_OUTPUT_TYPE=OUTPUT_DIR
export MLOPS_SPOOLER_DIR_PATH=/tmp/ta

# Configure the maximum number of files and the maximum file size for output files recording the statistics.
# If your prediction traffic is bursty, consider having more, larger files.
# If your environment is space-constrained, you may require a smaller file size.
export MLOPS_SPOOLER_MAX_FILES=5
export MLOPS_SPOOLER_FILE_MAX_SIZE=1045876000


ACTUALS_FILE="./actuals.csv"

# To run, first set your java home. For example:
if [[ -z ${JAVA_HOME} ]]; then
    if command -v /usr/libexec/java_home >/dev/null 2>&1 ; then
        export JAVA_HOME=$(/usr/libexec/java_home -v 1.8)
    else
        echo "JAVA_HOME needs to be set to run example.."
        exit 1
    fi
fi

rm -vf ${ACTUALS_FILE}
# Then execute the JAR file.
java -jar target/datarobot-mlops-predictions-data-demo-0.1.0.jar --deployment-id ${MLOPS_DEPLOYMENT_ID} --model-id ${MLOPS_MODEL_ID} --deployment-type Binary --num-samples 100 --features-csv-file-name ../../data/surgical-dataset.csv --actuals-csv-file-name ${ACTUALS_FILE}

# If the agent is running (and you have set the deployment ID as indicated above), you will see the statistics
# in the DataRobot UI under the Deployments tab.
