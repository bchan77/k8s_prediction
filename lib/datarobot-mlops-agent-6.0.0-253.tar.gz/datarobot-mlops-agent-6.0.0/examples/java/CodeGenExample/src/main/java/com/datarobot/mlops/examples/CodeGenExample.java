
package com.datarobot.mlops.examples;

import com.datarobot.mlops.MLOps;
import com.datarobot.mlops.common.exceptions.DRCommonException;
import com.datarobot.prediction.IClassificationPredictor;
import com.datarobot.prediction.IRegressionPredictor;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.datarobot.prediction.IPredictorInfo;
import com.datarobot.prediction.Predictors;

import java.io.FileReader;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;

public class CodeGenExample {

    CodeGenExample() {
    }

    public List<String[]> readAllDataAtOnce(String file) {
        List<String[]> allData = null;
        try {
            // Create an object of file reader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);

            // create csvReader object
            CSVReader csvReader = new CSVReaderBuilder(filereader)
                    .build();
            allData = csvReader.readAll();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return allData;
    }

    /**
     * Convert rows to a format that CodeGen uses for input
     * @param featureNames list of feature column names
     * @param rows input rows as arrays of strings
     * @param skipHeader whether to skip the first (header) row
     * @return rows converted into a list of feature name to value maps
     */
    public List<Map<String, Object>> convertRowsToListOfFeatureDicts(String[] featureNames, List<String[]> rows, Boolean skipHeader) {
        List<Map<String, Object>> listOfFeatureDicts = new ArrayList<>();

        int startRow = 0;
        if (skipHeader) {
            startRow = 1;
        }

        // convert each sample row to a map of <"feature name", feature value>
        for (String[] row : rows.subList(startRow, rows.size())) {
            Map<String, Object> sample = new HashMap<>();
            for (int i = 0; i < featureNames.length; ++i) {
                sample.put(featureNames[i], row[i]);
            }
            listOfFeatureDicts.add(sample);
        }
        return listOfFeatureDicts;
    }

    /**
     * Load the CodeGen model from the model jar file
     */
    IPredictorInfo loadModel(String modelFilePath) {
        IPredictorInfo predictor = null;
        try {
            File filePath = new File(modelFilePath);
            URL[] urls = new URL[]{new URL("file://" + filePath.getCanonicalPath())};

            // Create a new URLClassLoader to avoid class name conflicts in the jar
            URLClassLoader urlClassLoader = URLClassLoader.newInstance(urls, this.getClass().getClassLoader());
            predictor = Predictors.getPredictor(urlClassLoader);

        } catch (Exception e) {
            System.err.println("Failed to load model. " + e.getMessage());
            System.exit(1);
        }
        return predictor;
    }

    /**
     * Call the CodeGen model to make predictions on the samples
     * @param samples
     * @return list of predictions. For regression models, each prediction is a Double.
     */
    List<?> makeRegressionPredictions(IRegressionPredictor predictor, List<Map<String, Object>> samples) {
        List<Double> predictions = new ArrayList<>();

        for (Map<String, Object> sample : samples) {
            Double score = predictor.score(sample);

            predictions.add(score);
        }

        return predictions;
    }

    /**
     * Call the CodeGen model to make predictions on the samples
     * @param samples
     * @return list of predictions. For classification models, each prediction is a map of classname to probability
     *         (as a Double) for each possible class.
     */
    List<Map<String,Double>> makeClassificationPredictions(IClassificationPredictor predictor, List<Map<String, Object>> samples) {
        List<Map<String,Double>> predictions = new ArrayList<>();

        for (Map<String, Object> sample : samples) {
            // return map of each class label to its probability
            Map<String,Double> score = predictor.score(sample);
            predictions.add(score);
        }
        return predictions;
    }

    List<?> makePredictions(IPredictorInfo predictor, List<Map<String, Object>> samples) {
        List<?> predictions = null;

        if (predictor instanceof IRegressionPredictor) {
            predictions = makeRegressionPredictions((IRegressionPredictor)predictor, samples);
        } else if (predictor instanceof IClassificationPredictor) {
            predictions = makeClassificationPredictions((IClassificationPredictor)predictor, samples);
        } else {
            System.err.println("Unknown predictor type: " + predictor.getPredictorClass());
            System.exit(1);
        }

        return predictions;
    }

    /**
     * Sample code demonstrating how to use MLOps library to record metrics on classification predictions.
     * All code specific to MLOps library are commented with "MLOPS"
     */
    public void run(String modelFilePath, String csvFilePath) {
        IPredictorInfo predictor = loadModel(modelFilePath);

        List<String[]> rows = readAllDataAtOnce(csvFilePath);

        String[] headers = rows.get(0);
        List<Map<String, Object>> listOfFeatureMaps = convertRowsToListOfFeatureDicts(headers, rows, true);

        // MLOPS: declaration
        MLOps mlops = null;
        try {

            // MLOPS: initialize mlops instance, initialize it with the model ID from the CodeGen model
            mlops = MLOps.getInstance().init();

            // Call the model to generate predictions.
            long startTime = System.currentTimeMillis();
            List<?> predictions = makePredictions(predictor, listOfFeatureMaps);
            long endTime = System.currentTimeMillis();

            // MLOPS: report number of samples and time to produce predictions.
            mlops.reportDeploymentStats(listOfFeatureMaps.size(), endTime - startTime);

            // MLOPS: report feature data and predictions together to MLOps service;
            // this is used for feature drift and target drift calculation
            mlops.reportPredictionsDataList(listOfFeatureMaps, predictions);


        } catch (DRCommonException e) {
            System.out.println(e.getMessage());
            System.exit(-1);
        } finally {
            // MLOPS: shutdown
            if (mlops != null) {
                mlops.shutdown();
            }
        }
    }

    public static void main(String args[]) {
        String modelFilePath;
        String csvFilePath;

        try {
            modelFilePath = args[0];
            csvFilePath = args[1];
        } catch (Exception e) {
            String thisProgram = new java.io.File(CodeGenExample.class.getProtectionDomain()
                    .getCodeSource()
                    .getLocation()
                    .getPath())
                    .getName();
            System.err.println("Usage: java -jar " + thisProgram + " <codeGenModelFilePath> " + " <csvFilePath>");
            System.exit(1);
            return;
        }

        CodeGenExample codeGenExample = new CodeGenExample();
        codeGenExample.run(modelFilePath, csvFilePath);
    }
}
