library("datarobot.mlops")
library("caret")
library("stringi")

MLOpsInit()

datasetFilename <- file.path("../../data/surgical-dataset.csv")
dataset <- read.csv(datasetFilename, header = TRUE)

# Order of the class names in which predictions are reported to MLOps service, if not specified
# the order used during creation of the deployment is used.
class_names <- c("Yes", "No")

# create a list of indexes of 80% of the rows in the original dataset
# createDataPartition - creates random distribution of samples,
# if target field is categorical it tries to balance the class distributions within the partition
training_indexes <- createDataPartition(dataset$complication, p = 0.8, list = FALSE)

# create training dataset based on training_indexes
training_dataset <- dataset[training_indexes, ]

# create inference dataset based on not training_indexes
inference_dataset <- dataset[-training_indexes, ]

# convert complication field to categorical and train Random Forest classification model
model_rf <- train(training_dataset, as.factor(training_dataset[,"complication"]), method = "rf")

time.start <- Sys.time()
# predict
predictions <- predict.train(model_rf, inference_dataset, type = "prob")
time.finish <- Sys.time()
time.taken_msec <- as.integer((time.finish - time.start) * 1000)

# report deployment stats
MLOpsReportDeploymentStats(nrow(predictions), time.taken_msec)

associationIdList <- list()

df = data.frame(actualValue = character(), associationId = character(), timestamp = character())

numPredictions <- length(predictions[[1]])
# For simplicity, we generate random actual values
actualValues <- runif(numPredictions, min=0, max=1)
for (actualVal in actualValues) {
    if (actualVal > 0.5) {
        val <- "Yes"
    } else {
        val <- "No"
    }
    associationId <- stri_rand_strings(1, 32)
    associationIdList <- append(associationIdList, associationId)
    timestamp <- strftime(Sys.time(), format="%Y-%m-%d %H:%M:%OS3%z")
    # Add actual entry to the actuals dataframe
    entry <- list(actualValue = val, associationId = associationId, timestamp = timestamp)
    df = rbind(df, entry, stringsAsFactors=FALSE)
}

# Write actual values to the CSV to be uploaded later
write.csv(df, "./actuals.csv", row.names = FALSE)

# Report prediction data
MLOpsReportPredictionsData(features = inference_dataset, predictions = predictions, associationIds = associationIdList, classNames = class_names)

# shutdown mlops
MLOpsShutdown()

