library("datarobot.mlops")
library("caret")

MLOpsInit()

datasetFilename <- file.path("../../data/surgical-dataset.csv")
dataset <- read.csv(datasetFilename, header = TRUE)

# factorize(make categorical) label feature and get its distinct levels
class_names <- c("Yes", "No")

# create a list of indexes of 80% of the rows in the original dataset
# createDataPartition - creates random distribution of samples,
# if target field is categorical it tries to balance the class distributions within the partition
training_indexes <- createDataPartition(dataset$complication, p = 0.8, list = FALSE)

# create training dataset based on training_indexes
training_dataset <- dataset[training_indexes, ]

# create inference dataset based on not training_indexes
inference_dataset <- dataset[-training_indexes, ]

# convert complication field to categorical and train Random Forest classification model
model_rf <- train(training_dataset, as.factor(training_dataset[,"complication"]), method = "rf")

time.start <- Sys.time()
# predict
predictions <- predict.train(model_rf, inference_dataset, type = "prob")
time.finish <- Sys.time()
time.taken_msec <- as.integer((time.finish - time.start) * 1000)

# report deployment stats
MLOpsReportDeploymentStats(nrow(predictions), time.taken_msec)

# Report features and predictions together
MLOpsReportPredictionsData(features = inference_dataset, predictions = predictions, classNames = class_names)

# shutdown mlops
MLOpsShutdown()

