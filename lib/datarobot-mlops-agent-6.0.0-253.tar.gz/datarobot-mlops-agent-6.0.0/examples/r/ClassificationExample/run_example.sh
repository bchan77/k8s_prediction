# This example code shows how to use the MLOps library to report metrics from external models into
# DataRobot's model management service.

# First set your deployment ID and model ID. These can be obtained by running the script
# create_deployment.sh
#export MLOPS_DEPLOYMENT_ID=5
#export MLOPS_MODEL_ID=7

# Set your output type. To begin, you may wish the output to go to stdout.
# This will display the metrics to stdout instead of reporting them to DataRobot's
# service. This is useful during development.
export MLOPS_OUTPUT_TYPE=OUTPUT_DIR

# When you are ready to publish your metrics to the DataRobot service, you
# need to configure the output to be stored in a directory.
#export MLOPS_OUTPUT_TYPE=OUTPUT_DIR
export MLOPS_SPOOLER_DIR_PATH=/tmp/ta

# Configure the maximum number of files and the maximum file size for output files recording the statistics.
# If your prediction traffic is bursty, consider having more, larger files.
# If your environment is space-constrained, you may require a smaller file size.
export MLOPS_SPOOLER_MAX_FILES=5
export MLOPS_SPOOLER_FILE_MAX_SIZE=1045876000


# It is expected that Python MLOps library has been installed (through wheel distribution)
# If you are using Conda environment, install the wheel with --no-deps flag,
# if any dependencies are required for Conda env, install them with conda tools.
#pip install ../../../lib/datarobot_mlops-1.0.0-py2.py3-none-any.whl

# The example code uses various python packages that must be installed.
# If you are using Conda environment, install any dependencies wiht conda tools.
#pip install -r ../requirements.txt

# To run
echo ""
echo "Running R regression example..."
Rscript classification_example.r
echo "Run complete. Check UI for metrics."
