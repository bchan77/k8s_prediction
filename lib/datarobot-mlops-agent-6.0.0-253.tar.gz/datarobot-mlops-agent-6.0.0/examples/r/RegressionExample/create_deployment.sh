# Creates a model package from the configuration and creates an external deployment for it.

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. $DIR/../../examples_config_helper.sh
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"


# Model configuration
MODEL_CONFIG_FILE="${MODEL_CONFIG_DIR}/lending_club_regression.json"
TRAINING_DATA_FILE="${DATA_DIR}/lending-club-regression.csv"

# Name for the deployment
DEPLOYMENT_NAME="External R regression"

ARGS="--url ${MLOPS_SERVICE_URL} --token ${MLOPS_SERVICE_TOKEN}"
ARGS="${ARGS} --model-config ${MODEL_CONFIG_FILE} --training-data ${TRAINING_DATA_FILE}"

python ${TOOLS_DIR}/mlops_client.py deploy ${ARGS} --label "${DEPLOYMENT_NAME}"