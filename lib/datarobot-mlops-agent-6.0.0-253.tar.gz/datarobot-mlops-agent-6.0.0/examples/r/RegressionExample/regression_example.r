library("datarobot.mlops")
MLOpsInit()

# report deployment stats
MLOpsReportDeploymentStats(1000, 200)

# create list of values and report regression predictions
listVal <- c(1000, 2000, 3000, 4000)

# create features data as a dict and report it
dictVal <- list(tot_cur_bal = c(10000, 20000, 30000, 40000), annual_inc = c(55000, 75000, 80000, 100000))

MLOpsReportPredictionsData(features = dictVal, predictions = listVal)

# shutdown mlops
MLOpsShutdown()
