# This example code shows how to use the MLOps library to report metrics from external models into
# DataRobot's model management service.

# First set your deployment ID and model ID. These can be obtained by running the script to create_deployment.py

# Set your output type. To begin, you may wish the output to go to stdout.
# This will display the metrics to stdout instead of reporting them to DataRobot's
# service. This is useful during development.
#export MLOPS_OUTPUT_TYPE=STDOUT

# When you are ready to publish your metrics to the DataRobot service,
# uncomment the lines below.
# You need to configure the output to be stored in a directory and ensure that directory exists.
export MLOPS_OUTPUT_TYPE=OUTPUT_DIR
export MLOPS_SPOOLER_DIR_PATH=/tmp/ta

# Configure the maximum number of files and the maximum file size for output files recording the statistics.
# If your prediction traffic is bursty, consider having more, larger files.
# If your environment is space-constrained, you may require a smaller file size.
export MLOPS_SPOOLER_MAX_FILES=5
export MLOPS_SPOOLER_FILE_MAX_SIZE=1045876000


# Make sure Spark is configured
if [[ -z ${SPARK_BIN} ]]; then
    echo "SPARK_BIN needs to be set to the directory containing spark-submit."
    echo "For example, /opt/spark-2.4.5-bin-hadoop2.7/bin"
    exit 1
fi


# Then submit the Spark job
DATA_FILE="../../data/surgical-dataset.csv"

SPARK_OPTS="--num-executors 1 --driver-memory 512m --executor-memory 512m --executor-cores 4"
PROGRAM="pyspark_random_forest.py"
SPARK_CMD="${SPARK_BIN}/spark-submit ${SPARK_OPTS} ${PROGRAM}"

CMD="${SPARK_CMD} ${DATA_FILE}"
echo "${CMD}"
${CMD}

# If the agent is running (and you have set the deployment ID as indicated above), you will see the statistics
# in the DataRobot UI under the Deployments tab.
