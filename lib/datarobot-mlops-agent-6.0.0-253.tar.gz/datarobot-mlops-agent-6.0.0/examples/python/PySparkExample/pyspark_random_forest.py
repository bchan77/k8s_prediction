"""
An example program to demonstrate MLOps integration with PySpark.
"""
from __future__ import print_function

import sys

from pyspark.sql import SparkSession
from pyspark.mllib.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.tree import RandomForest
from datarobot.mlops.mlops import MLOps
import math
import time

if __name__ == "__main__":

    if len(sys.argv) != 2:
        print("Usage: pyspark_random_forest <file>", file=sys.stderr)
        sys.exit(-1)
    inputFile = sys.argv[1]

    spark = SparkSession\
        .builder\
        .appName("PythonRandomForest")\
        .getOrCreate()

    df = spark.read \
        .options(header="true", inferschema="true") \
        .csv(inputFile)

    transformed_df = df.rdd.map(lambda row: LabeledPoint(row[-1], Vectors.dense(row[0:-1])))

    # For demo purposes, rather than load a model, we train one here.
    model = RandomForest.trainClassifier(transformed_df, numClasses=2, categoricalFeaturesInfo={},
                                         numTrees=3, featureSubsetStrategy="auto",
                                         impurity="gini",
                                         maxDepth=4, maxBins=64,
                                         seed=0)

    # MLOPS: initialize MLOps
    mlops = MLOps().set_async_reporting(False).init()

    start_time = time.time()
    predictions = model.predict(transformed_df.map(lambda x: x.features))
    end_time = time.time()

    # MLOPS: report deployment metrics: number of predictions and execution time
    mlops.report_deployment_stats(predictions.count(), math.ceil(end_time - start_time))

    # MLOPS: report features and predictions
    # Note: to get good data on target drift, it is preferable to report probabilities for each
    # class, but the predict function doesn't give us that.
    predictionsProbabilities = predictions.map(lambda x: [1.0 - x, x])
    predictionsList = predictionsProbabilities.collect()

    mlops.report_predictions_data(features_df=df.toPandas(), predictions=predictionsList)

    print("******** Total predictions: {}".format(predictions.count()))

    # MLOPS: cleanup
    mlops.shutdown()

    spark.stop()
