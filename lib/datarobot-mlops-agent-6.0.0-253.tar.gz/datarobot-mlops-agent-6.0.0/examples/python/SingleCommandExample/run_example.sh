# This example code shows how to use the MLOps library to report metrics from external models into
# DataRobot's model management service.

# Source the MLOps service configuration, gets us the MLOPS_SERVICE_URL and
# MLOPS_SERVICE_TOKEN
. ./config.sh

# First set your deployment ID and model ID. These can be obtained by running the script
# create_deployment.sh
#export MLOPS_DEPLOYMENT_ID=5
#export MLOPS_MODEL_ID=7

# It is expected that Python MLOps library has been installed (through wheel distribution)
# If you are using Conda environment, install the wheel with --no-deps flag,
# if any dependencies are required for Conda env, install them with conda tools.
#pip install ../../../lib/datarobot_mlops-1.0.0-py2.py3-none-any.whl

# The example code uses various python packages that must be installed.
# If you are using Conda environment, install any dependencies wiht conda tools.
#pip install -r ../requirements.txt

# To run
echo ""
echo "Running classification example..."
python mlops_example.py --url ${MLOPS_SERVICE_URL} --token ${MLOPS_SERVICE_TOKEN}
echo "Run complete. Check UI for metrics."
