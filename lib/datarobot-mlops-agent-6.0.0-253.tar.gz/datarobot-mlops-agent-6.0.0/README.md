MLOps agent installation and usage
==================================

Unpack the MLOps Tar File
-------------------------

```
> tar -xvf datarobot-mlops-agent-6.0.0.tar.gz
```

Update the configuration file
-----------------------------

```
> cd datarobot-mlops-agent-6.0.0;
> <your-favorite-editor> ./conf/mlops.agent.conf.yaml
```

Run the MLOps agent
-------------------

Start the agent using the config file
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


```
> cd datarobot-mlops-agent-6.0.0;
> ./bin/start-agent.sh
```

Alternatively, start the agent using environment variables
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

```
> export AGENT_CONFIG_YAML=<path/to/conf/mlops.agent.conf.yaml> ; \
         export AGENT_LOG_PROPERTIES=<path/to/conf/mlops.log4j2.properties>; \
         export AGENT_JVM_OPT=-Xmx4G \
         export AGENT_JAR_PATH=<path/to/bin/mlops-agent-ver.jar> \
         sh -x /bin/start-agent.sh

 # AGENT_CONFIG_YAML      environmment variable to override the default path to mlops.agent.conf.yaml
 # AGENT_LOG_PROPERTIES   environmment variable to override the default path to mlops.agent.log4j.properties
 # AGENT_JVM_OPT          environmment variable to override the default JVM option `-Xmx4G`
 # AGENT_JAR_PATH         environmment variable to override the default JAR file path to agent-<ver>.jar
```

Check agent status
------------------------

```
> ./bin/status-agent.sh
```

Get agent status with real-time resource usage
----------------------------------------------------

```
> ./bin/status-agent.sh --verbose
```

Shut down the agent
--------------------

```
> ./bin/stop-agent.sh
```
